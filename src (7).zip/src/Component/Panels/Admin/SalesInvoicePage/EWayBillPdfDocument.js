// EWayBillPdfDocument.js
import React from 'react';
import { 
  Document, 
  Page, 
  Text, 
  View, 
  StyleSheet, 
  Font,
  Image 
} from '@react-pdf/renderer';

// Register fonts if needed
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v27/KFOmCnqEu92Fr1Mu4mxP.ttf' }
  ]
});

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 10,
    fontFamily: 'Helvetica',
    backgroundColor: '#ffffff'
  },
  header: {
    marginBottom: 10,
    borderBottom: '2px solid #000000',
    paddingBottom: 8
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    textTransform: 'uppercase'
  },
  headerSubtitle: {
    fontSize: 12,
    textAlign: 'center',
    marginTop: 2,
    color: '#555555'
  },
  section: {
    marginBottom: 8,
    padding: 6,
    border: '1px solid #cccccc',
    borderRadius: 2
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    marginBottom: 4,
    backgroundColor: '#f0f0f0',
    padding: 3
  },
  row: {
    flexDirection: 'row',
    marginBottom: 2
  },
  label: {
    width: '30%',
    fontWeight: 'bold',
    fontSize: 9
  },
  value: {
    width: '70%',
    fontSize: 9
  },
  table: {
    width: '100%',
    marginTop: 4
  },
  tableRow: {
    flexDirection: 'row',
    borderBottom: '1px solid #dddddd',
    paddingVertical: 3
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#e0e0e0',
    fontWeight: 'bold',
    paddingVertical: 4,
    paddingHorizontal: 2,
    borderBottom: '2px solid #000000'
  },
  tableCol: {
    fontSize: 8,
    paddingHorizontal: 2
  },
  col1: { width: '5%' },
  col2: { width: '20%' },
  col3: { width: '15%' },
  col4: { width: '10%' },
  col5: { width: '15%' },
  col6: { width: '15%' },
  col7: { width: '10%' },
  col8: { width: '10%' },
  footer: {
    marginTop: 10,
    borderTop: '1px solid #cccccc',
    paddingTop: 8
  },
  signature: {
    marginTop: 15,
    textAlign: 'right'
  },
  signatureLine: {
    width: 150,
    marginLeft: 'auto',
    borderBottom: '1px solid #000000',
    marginTop: 30,
    marginBottom: 5
  },
  qrContainer: {
    alignItems: 'center',
    marginTop: 10
  },
  qrImage: {
    width: 80,
    height: 80
  },
  statusBadge: {
    padding: 4,
    borderRadius: 2,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 10
  },
  statusGenerated: {
    backgroundColor: '#d4edda',
    color: '#155724'
  },
  statusCancelled: {
    backgroundColor: '#f8d7da',
    color: '#721c24'
  },
  statusPending: {
    backgroundColor: '#fff3cd',
    color: '#856404'
  }
});

const EWayBillPdfDocument = ({ 
  invoiceData, 
  invoiceNumber,
  gstBreakdown,
  isSameState,
  unitData,
  ewayBillStatus,
  irnDetails,
  companyInfo
}) => {
  
  // Format date helper
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'N/A';
    return `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
  };

  // Format currency
  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return '₹0.00';
    return `₹${parseFloat(amount).toFixed(2)}`;
  };

  // Get GST type based on transaction
  const getGstType = () => {
    if (isSameState) return 'CGST/SGST';
    return 'IGST';
  };

  // Get status badge style
  const getStatusStyle = () => {
    if (ewayBillStatus?.status === 'Generated') return styles.statusGenerated;
    if (ewayBillStatus?.status === 'Cancelled') return styles.statusCancelled;
    return styles.statusPending;
  };

  // Get status text
  const getStatusText = () => {
    if (ewayBillStatus?.status === 'Generated') return '✅ GENERATED';
    if (ewayBillStatus?.status === 'Cancelled') return '❌ CANCELLED';
    return '⏳ PENDING';
  };

  // Calculate total values
  const taxableAmount = parseFloat(invoiceData.taxableAmount) || 0;
  const totalGST = parseFloat(invoiceData.totalGST) || 0;
  const grandTotal = parseFloat(invoiceData.grandTotal) || 0;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>E-Way Bill</Text>
          <Text style={styles.headerSubtitle}>Electronic Way Bill - Government of India</Text>
          <Text style={[styles.headerSubtitle, { fontSize: 8, marginTop: 2 }]}>
            Generated under GST Act, 2017
          </Text>
        </View>

        {/* E-Way Bill Status */}
        <View style={styles.section}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View>
              <Text style={{ fontSize: 10, fontWeight: 'bold' }}>EWB No: {ewayBillStatus?.ewbNo || 'N/A'}</Text>
              <Text style={{ fontSize: 8, color: '#666' }}>
                Generated: {formatDate(ewayBillStatus?.generatedDate)}
              </Text>
            </View>
            <View style={[styles.statusBadge, getStatusStyle()]}>
              <Text>{getStatusText()}</Text>
            </View>
          </View>
        </View>

        {/* E-Invoice Reference */}
        {irnDetails && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>E-Invoice Reference</Text>
            <View style={styles.row}>
              <Text style={styles.label}>IRN:</Text>
              <Text style={styles.value}>{irnDetails.irn_no || 'N/A'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Ack No:</Text>
              <Text style={styles.value}>{irnDetails.ack_no || 'N/A'}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Ack Date:</Text>
              <Text style={styles.value}>{formatDate(irnDetails.ack_date)}</Text>
            </View>
          </View>
        )}

        {/* Invoice Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Invoice Details</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Invoice No:</Text>
            <Text style={styles.value}>{invoiceNumber}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Invoice Date:</Text>
            <Text style={styles.value}>{formatDate(invoiceData.invoiceDate)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Document Type:</Text>
            <Text style={styles.value}>{invoiceData.document_type || 'Sales Invoice'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Transaction Type:</Text>
            <Text style={styles.value}>{invoiceData.bb_bc?.toUpperCase() || 'B2B'}</Text>
          </View>
        </View>

        {/* Supplier Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Supplier Details</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.value}>{companyInfo.name || invoiceData.companyInfo.name}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>GSTIN:</Text>
            <Text style={styles.value}>{companyInfo.gstin || invoiceData.companyInfo.gstin}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Address:</Text>
            <Text style={styles.value}>{companyInfo.address || invoiceData.companyInfo.address}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>State:</Text>
            <Text style={styles.value}>
              {companyInfo.state || invoiceData.companyInfo.state} 
              (Code: {companyInfo.stateCode || invoiceData.companyInfo.stateCode})
            </Text>
          </View>
        </View>

        {/* Recipient Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recipient Details</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.value}>{invoiceData.supplierInfo.business_name || invoiceData.supplierInfo.name}</Text>
          </View>
          {invoiceData.bb_bc !== 'b2c' && (
            <View style={styles.row}>
              <Text style={styles.label}>GSTIN:</Text>
              <Text style={styles.value}>{invoiceData.supplierInfo.gstin || 'N/A'}</Text>
            </View>
          )}
          <View style={styles.row}>
            <Text style={styles.label}>Mobile:</Text>
            <Text style={styles.value}>{invoiceData.supplierInfo.mobile_number || 'N/A'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>State:</Text>
            <Text style={styles.value}>{invoiceData.supplierInfo.state || 'N/A'}</Text>
          </View>
        </View>

        {/* Transport Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Transport Details</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Transport Mode:</Text>
            <Text style={styles.value}>{invoiceData.transportDetails?.transport || 'Road'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Vehicle No:</Text>
            <Text style={styles.value}>{invoiceData.transportDetails?.vehicleNo || 'N/A'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>GR/RR No:</Text>
            <Text style={styles.value}>{invoiceData.transportDetails?.grNumber || 'N/A'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Station:</Text>
            <Text style={styles.value}>{invoiceData.transportDetails?.station || 'N/A'}</Text>
          </View>
        </View>

        {/* Item Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Item Summary</Text>
          <View style={styles.table}>
            <View style={styles.tableHeader}>
              <Text style={[styles.tableCol, styles.col1]}>#</Text>
              <Text style={[styles.tableCol, styles.col2]}>Product</Text>
              <Text style={[styles.tableCol, styles.col3]}>HSN Code</Text>
              <Text style={[styles.tableCol, styles.col4]}>Qty</Text>
              <Text style={[styles.tableCol, styles.col5]}>Rate</Text>
              <Text style={[styles.tableCol, styles.col6]}>Taxable Amt</Text>
              <Text style={[styles.tableCol, styles.col7]}>GST%</Text>
              <Text style={[styles.tableCol, styles.col8]}>Total</Text>
            </View>
            
            {invoiceData.items && invoiceData.items.map((item, index) => (
              <View key={index} style={styles.tableRow}>
                <Text style={[styles.tableCol, styles.col1, { textAlign: 'center' }]}>
                  {index + 1}
                </Text>
                <Text style={[styles.tableCol, styles.col2]}>{item.product}</Text>
                <Text style={[styles.tableCol, styles.col3]}>{item.hsn_code || '-'}</Text>
                <Text style={[styles.tableCol, styles.col4, { textAlign: 'center' }]}>
                  {item.quantity} {unitData[item.unit_id] || ''}
                </Text>
                <Text style={[styles.tableCol, styles.col5, { textAlign: 'right' }]}>
                  {formatCurrency(item.price)}
                </Text>
                <Text style={[styles.tableCol, styles.col6, { textAlign: 'right' }]}>
                  {formatCurrency((parseFloat(item.quantity) * parseFloat(item.price) * (1 - parseFloat(item.discount || 0) / 100)).toFixed(2))}
                </Text>
                <Text style={[styles.tableCol, styles.col7, { textAlign: 'center' }]}>
                  {item.gst}%
                </Text>
                <Text style={[styles.tableCol, styles.col8, { textAlign: 'right' }]}>
                  {formatCurrency(item.total)}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Financial Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Financial Summary</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Taxable Value:</Text>
            <Text style={styles.value}>{formatCurrency(taxableAmount)}</Text>
          </View>
          
          {isSameState ? (
            <>
              <View style={styles.row}>
                <Text style={styles.label}>CGST:</Text>
                <Text style={styles.value}>{formatCurrency(gstBreakdown.totalCGST)}</Text>
              </View>
              <View style={styles.row}>
                <Text style={styles.label}>SGST:</Text>
                <Text style={styles.value}>{formatCurrency(gstBreakdown.totalSGST)}</Text>
              </View>
            </>
          ) : (
            <View style={styles.row}>
              <Text style={styles.label}>IGST:</Text>
              <Text style={styles.value}>{formatCurrency(gstBreakdown.totalIGST)}</Text>
            </View>
          )}
          
          <View style={styles.row}>
            <Text style={styles.label}>Total GST:</Text>
            <Text style={styles.value}>{formatCurrency(totalGST)}</Text>
          </View>

          {invoiceData.additionalCharge && parseFloat(invoiceData.additionalChargeAmount) > 0 && (
            <View style={styles.row}>
              <Text style={styles.label}>{invoiceData.additionalCharge}:</Text>
              <Text style={styles.value}>{formatCurrency(invoiceData.additionalChargeAmount)}</Text>
            </View>
          )}

          {invoiceData.roundOff && parseFloat(invoiceData.roundOff) !== 0 && (
            <View style={styles.row}>
              <Text style={styles.label}>Round Off:</Text>
              <Text style={styles.value}>{formatCurrency(invoiceData.roundOff)}</Text>
            </View>
          )}

          <View style={[styles.row, { borderTop: '2px solid #000000', paddingTop: 4, marginTop: 4 }]}>
            <Text style={[styles.label, { fontSize: 11, fontWeight: 'bold' }]}>Grand Total:</Text>
            <Text style={[styles.value, { fontSize: 11, fontWeight: 'bold' }]}>
              {formatCurrency(grandTotal)}
            </Text>
          </View>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <View style={styles.row}>
            <Text style={[styles.label, { width: '50%' }]}>GST Type:</Text>
            <Text style={[styles.value, { width: '50%' }]}>{getGstType()}</Text>
          </View>
          <View style={styles.row}>
            <Text style={[styles.label, { width: '50%' }]}>Document Type:</Text>
            <Text style={[styles.value, { width: '50%' }]}>
              {invoiceData.document_type || 'Tax Invoice'}
            </Text>
          </View>
          <View style={styles.row}>
            <Text style={[styles.label, { width: '50%' }]}>Transaction Type:</Text>
            <Text style={[styles.value, { width: '50%' }]}>
              {invoiceData.bb_bc?.toUpperCase() || 'B2B'}
            </Text>
          </View>
          
          <View style={styles.signature}>
            <Text>For {companyInfo.name || invoiceData.companyInfo.name}</Text>
            <View style={styles.signatureLine} />
            <Text>Authorized Signatory</Text>
          </View>
        </View>

      </Page>
    </Document>
  );
};

export default EWayBillPdfDocument;