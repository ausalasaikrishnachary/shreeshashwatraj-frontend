export const baseurl = "http://localhost:5000";

// 🌐 LIVE SERVER (Production)
// export const baseurl = "http://72.61.237.40:5000";

// 🧪 TEST SERVER (Staging / Development)
// export const baseurl = "http://72.61.237.40:3000";

// 🌐 DEMO SERVER (DEMO)
// export const baseurl = "http://187.127.147.245:3000";

