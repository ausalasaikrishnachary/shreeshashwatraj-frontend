export const baseurl = "http://localhost:5000";

// export const baseurl = "http://193.203.163.62:3000"
