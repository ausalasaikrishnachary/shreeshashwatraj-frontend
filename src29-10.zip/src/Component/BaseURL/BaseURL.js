export const baseurl = "http://localhost:5000";

// export const baseurl = "http://145.79.0.94:5000"
