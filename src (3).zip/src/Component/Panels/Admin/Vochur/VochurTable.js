import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminSidebar from '../../../Shared/AdminSidebar/AdminSidebar';
import AdminHeader from '../../../Shared/AdminSidebar/AdminHeader';
import ReusableTable from '../../../Layouts/TableLayout/DataTable';
import { baseurl } from '../../../BaseURL/BaseURL';
import './Voucher.css';

const VochurTable = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [suppliers, setSuppliers] = useState([]);
  const [receiptData, setReceiptData] = useState([]);
  const [nextReceiptNumber, setNextReceiptNumber] = useState('REC001');
  const [hasFetchedReceiptNumber, setHasFetchedReceiptNumber] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [month, setMonth] = useState('July');
  const [year, setYear] = useState('2025');
  const [startDate, setStartDate] = useState('2025-06-08');
  const [endDate, setEndDate] = useState('2025-07-08');
  const [activeTab, setActiveTab] = useState('Voucher');
  const [invoices, setInvoices] = useState([]);
  const [selectedInvoice, setSelectedInvoice] = useState('');
  const [invoiceBalance, setInvoiceBalance] = useState(0);
  const [isFetchingBalance, setIsFetchingBalance] = useState(false);

  const [formData, setFormData] = useState({
    receiptNumber: 'REC001',
    supplierId: '',
    amount: '',
    currency: 'INR',
    paymentMethod: 'Direct Deposit',
    receiptDate: new Date().toISOString().split('T')[0],
    note: '',
    bankName: '',
    transactionDate: '',
    reconciliationOption: 'Do Not Reconcile',
    supplierMobile: '',
    supplierEmail: '',
    supplierGstin: '',
    suppliername: '',
    transactionProofFile: '',
    invoiceNumber: ''
  });

  const fetchInvoices = async () => {
    try {
      console.log('Fetching invoices from:', `${baseurl}/api/purchasevouchersnumber`);
      const response = await fetch(`${baseurl}/api/purchasevouchersnumber?type=Purchase`);
      if (response.ok) {
        const data = await response.json();
        console.log('Received invoices data:', data);
        
        if (Array.isArray(data)) {
          const invoiceNumbers = data.map(invoice => ({
            id: invoice.VoucherID || invoice.id || Math.random(),
            number: invoice.VchNo || invoice.invoice_number || invoice.number || 'Unknown',
            total_amount: invoice.TotalAmount || invoice.total_amount || 0,
            paid_amount: invoice.paid_amount || 0
          }));
          console.log('Processed invoice numbers:', invoiceNumbers);
          setInvoices(invoiceNumbers);
        } else if (typeof data === 'object') {
          const invoiceArray = data.invoices || data.data || [];
          const invoiceNumbers = invoiceArray.map(invoice => ({
            id: invoice.VoucherID || invoice.id || Math.random(),
            number: invoice.VchNo || invoice.invoice_number || invoice.number || 'Unknown',
            total_amount: invoice.TotalAmount || invoice.total_amount || 0,
            paid_amount: invoice.paid_amount || 0
          }));
          console.log('Processed invoice numbers from object:', invoiceNumbers);
          setInvoices(invoiceNumbers);
        } else {
          console.warn('Unexpected invoices data format:', data);
          setInvoices([]);
        }
      } else {
        console.error('Failed to fetch invoices. Status:', response.status);
        await fetchInvoicesFromAlternativeEndpoint();
      }
    } catch (err) {
      console.error('Error fetching invoices:', err);
      await fetchInvoicesFromAlternativeEndpoint();
    }
  };

  const fetchInvoicesFromAlternativeEndpoint = async () => {
    try {
      console.log('Trying alternative endpoint for invoices...');
      const endpoints = [
        `${baseurl}/api/invoices`,
        `${baseurl}/api/purchase-invoices`,
        `${baseurl}/api/purchasevouchers`
      ];
      
      for (const endpoint of endpoints) {
        try {
          const response = await fetch(endpoint);
          if (response.ok) {
            const data = await response.json();
            console.log(`Found invoices at ${endpoint}:`, data);
            
            if (Array.isArray(data)) {
              const invoiceNumbers = data.map(invoice => ({
                id: invoice.id || invoice.VoucherID || Math.random(),
                number: invoice.invoice_number || invoice.VchNo || invoice.number || 'Unknown',
                total_amount: invoice.TotalAmount || invoice.total_amount || invoice.amount || 0,
                paid_amount: invoice.paid_amount || 0
              }));
              setInvoices(invoiceNumbers);
              return;
            }
          }
        } catch (err) {
          console.log(`Failed to fetch from ${endpoint}:`, err);
        }
      }
      
      setInvoices([]);
    } catch (err) {
      console.error('Error in alternative invoice fetch:', err);
      setInvoices([]);
    }
  };

 const fetchInvoiceBalance = async (supplierId, invoiceNumber) => {
  if (!supplierId || !invoiceNumber) {
    setInvoiceBalance(0);
    setFormData(prev => ({
      ...prev,
      amount: ''
    }));
    return;
  }

  try {
    setIsFetchingBalance(true);
    console.log(`Fetching balance for supplier ${supplierId}, invoice ${invoiceNumber}`);
    
    // Check in existing receipt data first (from your API response)
    const existingReceipt = receiptData.find(receipt => {
      // Match by supplier ID and invoice number
      const receiptSupplierId = receipt.PartyID || receipt.supplier?.id || receipt.AccountID;
      const receiptInvoiceNumbers = receipt.invoice_numbers || [receipt.InvoiceNumber];
      
      return receiptSupplierId == supplierId && 
             receiptInvoiceNumbers.includes(invoiceNumber);
    });

    if (existingReceipt) {
      console.log('Found existing receipt data:', existingReceipt);
      
      // Try different possible balance fields
      const balanceAmount = 
        existingReceipt.total_balance_amount ||
        existingReceipt.balance_amount ||
        (parseFloat(existingReceipt.total_invoice_amount || 0) - 
         parseFloat(existingReceipt.total_paid_amount || 0)) ||
        (parseFloat(existingReceipt.TotalAmount || 0) - 
         parseFloat(existingReceipt.paid_amount || 0)) ||
        0;
      
      console.log('Calculated balance from existing data:', balanceAmount);
      
      if (balanceAmount > 0) {
        setInvoiceBalance(balanceAmount);
        setFormData(prev => ({
          ...prev,
          amount: balanceAmount
        }));
      } else {
        setInvoiceBalance(0);
        setFormData(prev => ({
          ...prev,
          amount: ''
        }));
        alert('This invoice has no outstanding balance.');
      }
      
      setIsFetchingBalance(false);
      return;
    }

    // If not found in existing data, call the API
    try {
      const response = await fetch(
        `${baseurl}/api/purchase-invoice-balance?supplier_id=${supplierId}&invoice_number=${invoiceNumber}`
      );
      
      if (response.ok) {
        const data = await response.json();
        console.log('Received balance data from API:', data);
        
        // Extract balance from API response
        const balanceAmount = 
          data.total_balance_amount ||
          data.balance_amount ||
          data.balance ||
          data.amount_due ||
          (parseFloat(data.total_invoice_amount || 0) - parseFloat(data.total_paid_amount || 0)) ||
          0;
        
        console.log('Extracted balance amount:', balanceAmount);
        
        if (balanceAmount > 0) {
          setInvoiceBalance(balanceAmount);
          setFormData(prev => ({
            ...prev,
            amount: balanceAmount
          }));
        } else {
          setInvoiceBalance(0);
          setFormData(prev => ({
            ...prev,
            amount: ''
          }));
          alert('This invoice is already fully paid or has no balance.');
        }
      } else {
        console.warn('Balance API returned status:', response.status);
        // Fallback to local invoice data
        await fetchBalanceFromLocalInvoices(invoiceNumber);
      }
    } catch (apiError) {
      console.error('API error fetching balance:', apiError);
      // Fallback to local invoice data
      await fetchBalanceFromLocalInvoices(invoiceNumber);
    }
  } catch (err) {
    console.error('Error in fetchInvoiceBalance:', err);
    setInvoiceBalance(0);
    setFormData(prev => ({
      ...prev,
      amount: ''
    }));
  } finally {
    setIsFetchingBalance(false);
  }
};

// Helper function to fetch balance from local invoices data
const fetchBalanceFromLocalInvoices = async (invoiceNumber) => {
  const selectedInvoiceData = invoices.find(inv => inv.number === invoiceNumber);
  if (selectedInvoiceData) {
    const invoiceAmount = parseFloat(selectedInvoiceData.total_amount || 0);
    const paidAmount = parseFloat(selectedInvoiceData.paid_amount || 0);
    const balance = invoiceAmount - paidAmount;
    
    if (balance > 0) {
      setInvoiceBalance(balance);
      setFormData(prev => ({
        ...prev,
        amount: balance
      }));
    } else {
      setInvoiceBalance(0);
      setFormData(prev => ({
        ...prev,
        amount: ''
      }));
      alert('This invoice is already fully paid based on local data.');
    }
  } else {
    console.log('Invoice not found in local data');
    // Show empty amount
    setInvoiceBalance(0);
    setFormData(prev => ({
      ...prev,
      amount: ''
    }));
  }
};
useEffect(() => {
  console.log('Balance fetch triggered:', {
    supplierId: formData.supplierId,
    invoiceNumber: formData.invoiceNumber,
    hasSupplier: !!formData.supplierId,
    hasInvoice: !!formData.invoiceNumber
  });
  
  if (formData.supplierId && formData.invoiceNumber) {
    const timer = setTimeout(() => {
      fetchInvoiceBalance(formData.supplierId, formData.invoiceNumber);
    }, 300);
    
    return () => clearTimeout(timer);
  } else {
    // Clear amount if either is missing
    setInvoiceBalance(0);
    setFormData(prev => ({
      ...prev,
      amount: ''
    }));
  }
}, [formData.supplierId, formData.invoiceNumber]);

  // File change handler
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('File size should be less than 5MB');
        return;
      }
      
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!allowedTypes.includes(file.type)) {
        alert('Please select a valid file type (PDF, JPG, PNG, DOC, DOCX)');
        return;
      }
    
      setFormData(prev => ({
        ...prev,
        transactionProofFile: file
      }));
    }
  };

  // File remove handler
  const handleRemoveFile = () => {
    setFormData(prev => ({
      ...prev,
      transactionProofFile: null
    }));
  };

  const receiptStats = [
    { label: 'Total Receipts', value: '₹ 2,50,000', change: '+18%', type: 'total' },
    { label: 'Cash Receipts', value: '₹ 1,50,000', change: '+15%', type: 'cash' },
    { label: 'Bank Receipts', value: '₹ 80,000', change: '+20%', type: 'bank' },
    { label: 'Digital Receipts', value: '₹ 20,000', change: '+25%', type: 'digital' }
  ];

  const columns = [
    { 
      key: 'payee', 
      title: 'Supplier Name', 
      style: { textAlign: 'left' },
      render: (value, row) => {
        const businessName =
          row?.supplier?.business_name ||
          row?.payee_name ||
          row?.supplier_name ||
          'N/A';

        return businessName;
      }
    },
    { 
      key: 'VchNo', 
      title: 'VOUCHER NUMBER', 
      style: { textAlign: 'center' },
      render: (value, row) => (
        <button
          className="btn btn-link p-0 text-primary text-decoration-none"
          onClick={() => handleViewReceipt(row.VoucherID)}
          title="Click to view receipt"
        >
          {value || 'N/A'}
        </button>
      )
    },
    { 
      key: 'paid_amount', 
      title: 'AMOUNT', 
      style: { textAlign: 'right' },
      render: (value) => value || '₹ 0.00'
    },
    { 
      key: 'payment_method', 
      title: 'PAYMENT METHOD', 
      style: { textAlign: 'center' },
      render: (value) => value || 'N/A'
    },
    {
      key:'InvoiceNumber',
      title:'Accounting',
      style:{textAlign:'center'},
      render:(value) => value || '0'
    },
    {
      key: 'Date',
      title: 'DATE',
      style: { textAlign: 'center' },
      render: (value) => {
        if (!value) return 'N/A';

        const dateObj = new Date(value);
        const day = String(dateObj.getDate()).padStart(2, '0');
        const month = String(dateObj.getMonth() + 1).padStart(2, '0');
        const year = dateObj.getFullYear();

        return `${day}-${month}-${year}`;
      }
    }
  ];

  const tabs = [
    { name: 'Purchase Invoice', path: '/purchase/purchase-invoice' },
    { name: 'Purchase Order', path: '/purchase/purchase-order' },
    { name: 'Voucher', path: '/purchase/voucher' },
    { name: 'Debit Note', path: '/purchase/debit-note' },
    { name: 'Payables', path: '/purchase/payables' }
  ];

  // Fetch next receipt number
  const fetchNextReceiptNumber = async () => {
    try {
      console.log('Fetching next receipt number from:', `${baseurl}/api/next-receipt-number`);
      const response = await fetch(`${baseurl}/api/next-receipt-number`);
      if (response.ok) {
        const data = await response.json();
        console.log('Received next receipt number:', data.nextReceiptNumber);
        setNextReceiptNumber(data.nextReceiptNumber);
        setFormData(prev => ({
          ...prev,
          receiptNumber: data.nextReceiptNumber
        }));
        setHasFetchedReceiptNumber(true);
      } else {
        console.error('Failed to fetch next receipt number. Status:', response.status);
        await generateFallbackReceiptNumber();
      }
    } catch (err) {
      console.error('Error fetching next receipt number:', err);
      await generateFallbackReceiptNumber();
    }
  };

  // Fallback receipt number generation
  const generateFallbackReceiptNumber = async () => {
    try {
      console.log('Attempting fallback receipt number generation...');
      const response = await fetch(`${baseurl}/api/last-receipt`);
      if (response.ok) {
        const data = await response.json();
        if (data.lastReceiptNumber) {
          const lastNumber = data.lastReceiptNumber;
          const numberMatch = lastNumber.match(/REC(\d+)/);
          if (numberMatch) {
            const nextNum = parseInt(numberMatch[1], 10) + 1;
            const fallbackReceiptNumber = `REC${nextNum.toString().padStart(3, '0')}`;
            console.log('Fallback receipt number generated:', fallbackReceiptNumber);
            setNextReceiptNumber(fallbackReceiptNumber);
            setFormData(prev => ({
              ...prev,
              receiptNumber: fallbackReceiptNumber
            }));
            setHasFetchedReceiptNumber(true);
            return;
          }
        }
      }
      // Default fallback
      setNextReceiptNumber('REC001');
      setFormData(prev => ({
        ...prev,
        receiptNumber: 'REC001'
      }));
      setHasFetchedReceiptNumber(true);
    } catch (err) {
      console.error('Error in fallback receipt number generation:', err);
      setNextReceiptNumber('REC001');
      setFormData(prev => ({
        ...prev,
        receiptNumber: 'REC001'
      }));
      setHasFetchedReceiptNumber(true);
    }
  };

const fetchReceipts = async () => {
  try {
    setIsLoading(true);
    console.log('Fetching receipts from:', `${baseurl}/api/voucher`);
    const response = await fetch(`${baseurl}/api/voucher`);
    if (response.ok) {
      const data = await response.json();
      console.log('Received receipts data (first item):', data[0]);
      
      const sortedData = data.sort((a, b) => {
        const dateA = new Date(a.receipt_date || a.created_at);
        const dateB = new Date(b.receipt_date || b.created_at);
        return dateB - dateA || b.id - a.id;
      });

      const transformedData = sortedData.map(receipt => {
        // Calculate balance amount if not present
        const totalAmount = parseFloat(receipt.TotalAmount || receipt.total_amount || 0);
        const paidAmount = parseFloat(receipt.paid_amount || 0);
        const balanceAmount = receipt.total_balance_amount || 
                             receipt.balance_amount || 
                             (totalAmount - paidAmount);
        
        return {
          ...receipt,
          id: receipt.id || '',
          supplier: receipt.supplier || {
            business_name: receipt.payee_name || receipt.supplier_name || receipt.PartyName || 'N/A' 
          },
          payee: receipt.supplier?.business_name || receipt.payee_name || receipt.supplier_name || receipt.PartyName || 'N/A',
          amount: `₹ ${parseFloat(receipt.amount || totalAmount).toLocaleString('en-IN')}`,
          receipt_date: receipt.receipt_date ? new Date(receipt.receipt_date).toLocaleDateString('en-IN') : 'N/A',
          payment_method: receipt.payment_method || 'N/A',
          invoice_numbers: receipt.invoice_numbers || receipt.InvoiceNumber || 'N/A',
          total_balance_amount: balanceAmount,
          // Add fields for easier matching
          PartyID: receipt.PartyID,
          AccountID: receipt.AccountID,
          InvoiceNumber: receipt.InvoiceNumber
        };
      });

      console.log('Transformed receipts data (first item):', transformedData[0]);
      
      setReceiptData(transformedData);
    } else {
      console.error('Failed to fetch receipts. Status:', response.status);
      alert('Failed to load receipts. Please try again later.');
    }
  } catch (err) {
    console.error('Error fetching receipts:', err);
    alert('Error connecting to server. Please check your network connection.');
  } finally {
    setIsLoading(false);
  }
};

  const fetchSuppliers = async () => {
    try {
      const res = await fetch(`${baseurl}/accounts`);
      if (res.ok) {
        const data = await res.json();
        const supplierAccounts = data.filter(acc => acc.role === "supplier");
        setSuppliers(supplierAccounts);
      } else {
        console.error('Failed to fetch suppliers:', res.statusText);
        alert('Failed to load suppliers. Please try again later.');
      }
    } catch (err) {
      console.error('Error fetching suppliers:', err);
      alert('Error connecting to server. Please check your network or try again later.');
    }
  };

  useEffect(() => {
    console.log('Component mounted, fetching initial data...');
    fetchSuppliers();
    fetchReceipts();
    fetchNextReceiptNumber();
    fetchInvoices();
  }, []);

  // Tab navigation
  const handleTabClick = (tab) => {
    setActiveTab(tab.name);
    navigate(tab.path);
  };

  // Create receipt modal
  const handleCreateClick = async () => {
    console.log('Create button clicked, current receipt number:', nextReceiptNumber);
    if (!hasFetchedReceiptNumber) {
      console.log('Voucher number not fetched yet, fetching now...');
      await fetchNextReceiptNumber();
    }
    
    // Reset form data for new voucher
    setFormData(prev => ({
      ...prev,
      supplierId: '',
      amount: '',
      invoiceNumber: '',
      note: '',
      bankName: '',
      transactionDate: '',
      transactionProofFile: ''
    }));
    setSelectedInvoice('');
    setInvoiceBalance(0);
    
    setIsModalOpen(true);
  };

  // Close modal and reset form
  const handleCloseModal = () => {
    console.log('Closing modal');
    setIsModalOpen(false);
    setFormData(prev => ({
      ...prev,
      supplierId: '',
      amount: '',
      currency: 'INR',
      paymentMethod: 'Direct Deposit',
      receiptDate: new Date().toISOString().split('T')[0],
      note: '',
      bankName: '',
      transactionDate: '',
      reconciliationOption: 'Do Not Reconcile',
      receiptNumber: nextReceiptNumber,
      invoiceNumber: '',
      transactionProofFile: ''
    }));
    setSelectedInvoice('');
    setInvoiceBalance(0);
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    console.log(`Form field changed: ${name} = ${value}`);
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (name === 'amount') {
      if (value !== invoiceBalance.toString()) {
      }
    }
  };

  // Handle supplier selection change
const handleSupplierChange = (e) => {
  const selectedSupplierId = e.target.value;
  const selectedSupplier = suppliers.find(supp => supp.id == selectedSupplierId);
  
  if (!selectedSupplier) {
    console.error('Supplier not found with ID:', selectedSupplierId);
    return;
  }
  
  console.log('Selected Supplier:', {
    id: selectedSupplier.id,
    name: selectedSupplier.name, // Person's name
    business_name: selectedSupplier.business_name, // Business name
    mobile: selectedSupplier.mobile_number,
    email: selectedSupplier.email,
    gstin: selectedSupplier.gstin
  });
  
  setFormData(prev => ({
    ...prev,
    supplierId: selectedSupplierId,
    supplierMobile: selectedSupplier.mobile_number || '',
    supplierEmail: selectedSupplier.email || '',
    supplierGstin: selectedSupplier.gstin || '',
    suppliername: selectedSupplier.name || '', // Store person's name here
    business_name: selectedSupplier.business_name || '', // Store business name separately
    amount: '' 
  }));
  
  setInvoiceBalance(0);
  
  // If invoice is already selected, fetch balance
  if (formData.invoiceNumber) {
    fetchInvoiceBalance(selectedSupplierId, formData.invoiceNumber);
  }
};

  // Handle invoice selection change
  const handleInvoiceChange = (e) => {
    const selectedVchNo = e.target.value;
    setSelectedInvoice(selectedVchNo);
    setFormData(prev => ({
      ...prev,
      invoiceNumber: selectedVchNo,
      amount: '' // Clear amount when invoice changes
    }));
    if (formData.supplierId) {
      fetchInvoiceBalance(formData.supplierId, selectedVchNo);
    }
  };

const handleCreateReceipt = async () => {
  // Validation
  if (!formData.supplierId) {
    alert('Please select a supplier');
    return;
  }
  if (!formData.amount || parseFloat(formData.amount) <= 0) {
    alert('Please enter a valid amount');
    return;
  }
  if (!formData.receiptDate) {
    alert('Please select a receipt date');
    return;
  }

  try {
    setIsLoading(true);
    
    // Get the selected supplier details
    const selectedSupplier = suppliers.find(supp => supp.id == formData.supplierId);
    if (!selectedSupplier) {
      alert('Supplier not found');
      setIsLoading(false);
      return;
    }
    
    const formDataToSend = new FormData();
    
    formDataToSend.append('retailer_id', formData.supplierId);
    
    formDataToSend.append('retailer_name', selectedSupplier.name || '');
    
    if (selectedSupplier.business_name) {
      formDataToSend.append('business_name', selectedSupplier.business_name);
    }
    
    // Other required fields
    formDataToSend.append('amount', formData.amount);
    formDataToSend.append('bank_name', formData.bankName || '');
    formDataToSend.append('invoice_number', formData.invoiceNumber || '');
    formDataToSend.append('TransactionType', 'purchase voucher');
    formDataToSend.append('data_type', 'Purchase');
    
    // Optional fields
    formDataToSend.append('currency', formData.currency || 'INR');
    formDataToSend.append('payment_method', formData.paymentMethod || 'Direct Deposit');
    formDataToSend.append('receipt_date', formData.receiptDate);
    formDataToSend.append('note', formData.note || '');
    formDataToSend.append('transaction_date', formData.transactionDate || '');
    
    // Supplier contact details
    if (selectedSupplier.mobile_number) {
      formDataToSend.append('supplier_mobile', selectedSupplier.mobile_number);
    }
    if (selectedSupplier.email) {
      formDataToSend.append('supplier_email', selectedSupplier.email);
    }
    if (selectedSupplier.gstin) {
      formDataToSend.append('supplier_gstin', selectedSupplier.gstin);
    }

    // Append file if exists
    if (formData.transactionProofFile) {
      formDataToSend.append('transaction_proof', formData.transactionProofFile);
    }

    // Debug: Log what we're sending
    console.log('=== SENDING DATA TO BACKEND ===');
    console.log('Supplier ID:', formData.supplierId);
    console.log('Supplier Name (person):', selectedSupplier.name);
    console.log('Business Name:', selectedSupplier.business_name);
    console.log('Amount:', formData.amount);
    console.log('Invoice Number:', formData.invoiceNumber);
    console.log('TransactionType:', 'purchase voucher');
    console.log('data_type:', 'Purchase');
    
    // Log all FormData entries
    console.log('FormData entries:');
    for (let [key, value] of formDataToSend.entries()) {
      console.log(`${key}: ${value}`);
    }

    // Make the API call
    const response = await fetch(`${baseurl}/api/receipts`, {
      method: 'POST',
      body: formDataToSend,
    });

    console.log('Response status:', response.status);
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ Voucher created successfully:', result);
      
      // Refresh the receipts list
      await fetchReceipts();
      
      // Close modal
      handleCloseModal();
      
      alert('Voucher created successfully!');
      
      // Navigate to view page
      if (result.voucherId) {
        navigate(`/voucher_view/${result.voucherId}`);
      } else if (result.id) {
        navigate(`/voucher_view/${result.id}`);
      }

      // Generate next receipt number
      await fetchNextReceiptNumber();
    } else {
      const errorText = await response.text();
      console.error('❌ Failed to create voucher. Status:', response.status);
      console.error('Error response:', errorText);
      
      let errorMessage = 'Failed to create voucher. ';
      try {
        const errorData = JSON.parse(errorText);
        errorMessage += errorData.error || errorData.message || 'Please try again.';
      } catch {
        errorMessage += 'Please try again.';
      }
      alert(errorMessage);
    }
  } catch (err) {
    console.error('❌ Error creating voucher:', err);
    alert('Network error. Please check your connection and try again.');
  } finally {
    setIsLoading(false);
  }
};

  // View receipt details
  const handleViewReceipt = (receiptId) => {
    console.log('View receipt:', receiptId);
    navigate(`/voucher_view/${receiptId}`);
  };

  // Download receipts
  const handleDownload = () => {
    alert(`Downloading receipts for ${month} ${year}`);
  };

  // Download date range receipts
  const handleDownloadRange = () => {
    alert(`Downloading receipts from ${startDate} to ${endDate}`);
  };

  return (
    <div className="receipts-wrapper">
      <AdminSidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
      <div className={`receipts-main-content ${isCollapsed ? 'collapsed' : ''}`}>
        <AdminHeader isCollapsed={isCollapsed} />
        <div className="receipts-content-area">
          {/* Tabs Section */}
          <div className="receipts-tabs-section">
            <div className="receipts-tabs-container">
              {tabs.map((tab) => (
                <button
                  key={tab.name}
                  className={`receipts-tab ${activeTab === tab.name ? 'receipts-tab--active' : ''}`}
                  onClick={() => handleTabClick(tab)}
                >
                  {tab.name}
                </button>
              ))}
            </div>
          </div>

          {/* Header Section */}
          <div className="receipts-header-section">
            <div className="receipts-header-top">
              <div className="receipts-title-section">
                <h1 className="receipts-main-title">Voucher Management</h1>
                <p className="receipts-subtitle">Create, manage and track all your payment receipts</p>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="receipts-stats-grid">
            {receiptStats.map((stat, index) => (
              <div key={index} className={`receipts-stat-card receipts-stat-card--${stat.type}`}>
                <h3 className="receipts-stat-label">{stat.label}</h3>
                <div className="receipts-stat-value">{stat.value}</div>
                <div className={`receipts-stat-change ${stat.change.startsWith('+') ? 'receipts-stat-change--positive' : 'receipts-stat-change--negative'}`}>
                  {stat.change} from last month
                </div>
              </div>
            ))}
          </div>

          {/* Actions Section */}
          <div className="receipts-actions-section">
            <div className="quotation-container p-3">
              <h5 className="mb-3 fw-bold">View Receipts</h5>
              {/* Filters and Actions */}
              <div className="row align-items-end g-3 mb-3">
                <div className="col-md-auto">
                  <label className="form-label mb-1">Select Month and Year Data:</label>
                  <div className="d-flex">
                    <select
                      className="form-select me-2"
                      value={month}
                      onChange={(e) => setMonth(e.target.value)}
                    >
                      <option>January</option>
                      <option>February</option>
                      <option>March</option>
                      <option>April</option>
                      <option>May</option>
                      <option>June</option>
                      <option>July</option>
                      <option>August</option>
                      <option>September</option>
                      <option>October</option>
                      <option>November</option>
                      <option>December</option>
                    </select>
                    <select
                      className="form-select"
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                    >
                      <option>2025</option>
                      <option>2024</option>
                      <option>2023</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-auto">
                  <button
                    className="btn btn-success mt-4"
                    onClick={handleDownload}
                    disabled={isLoading}
                  >
                    <i className="bi bi-download me-1"></i> Download
                  </button>
                </div>
                <div className="col-md-auto">
                  <label className="form-label mb-1">Select Date Range:</label>
                  <div className="d-flex">
                    <input
                      type="date"
                      className="form-control me-2"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                    <input
                      type="date"
                      className="form-control"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>
                <div className="col-md-auto">
                  <button
                    className="btn btn-success mt-4"
                    onClick={handleDownloadRange}
                    disabled={isLoading}
                  >
                    <i className="bi bi-download me-1"></i> Download Range
                  </button>
                </div>
                <div className="col-md-auto">
                  <button
                    className="btn btn-info text-white mt-4"
                    onClick={handleCreateClick}
                    disabled={isLoading}
                  >
                    {isLoading ? 'Creating...' : 'Create Voucher'}
                  </button>
                </div>
              </div>

              {/* Receipts Table */}
              <ReusableTable
                title="Receipts"
                data={receiptData} 
                columns={columns}
                searchPlaceholder="Search receipts..."
                initialEntriesPerPage={5}
                showSearch={true}
                showEntriesSelector={false} 
                showPagination={true}
                isLoading={isLoading}
              />
            </div>
          </div>

          {/* Create Voucher Modal */}
          {isModalOpen && (
            <div className="modal" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
              <div className="modal-dialog modal-lg">
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title">Create Voucher</h5>
                    <button
                      type="button"
                      className="btn-close"
                      onClick={handleCloseModal}
                      disabled={isLoading}
                    ></button>
                  </div>
                  <div className="modal-body">
                    <div className="row mb-4">
                      <div className="col-md-6">
                        <div className="company-info-recepits-table text-center">
                          <label className="form-label-recepits-table">Navkar Exports</label>
                          <p>NO.63/603 AND 64/604, NEAR JAIN TEMPLE</p>
                          <p>1ST MAIN ROAD, T DASARAHALLI</p>
                          <p>GST : 29AAAMPC7994B1ZE</p>
                          <p>Email: akshay555.ak@gmail.com</p>
                          <p>Phone: 09880990431</p>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Voucher Number</label>
                          <input
                            type="text"
                            className="form-control"
                            name="receiptNumber"
                            value={formData.receiptNumber}
                            onChange={handleInputChange}
                            placeholder="REC0001"
                            readOnly
                          />
                        </div>
                        <div className="mb-3">
                          <label className="form-label">Voucher Date</label>
                          <input
                            type="date"
                            className="form-control"
                            name="receiptDate"
                            value={formData.receiptDate}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="mb-3">
                          <label className="form-label">Payment Method</label>
                          <select
                            className="form-select"
                            name="paymentMethod"
                            value={formData.paymentMethod}
                            onChange={handleInputChange}
                          >
                            <option>Direct Deposit</option>
                            <option>Online Payment</option>
                            <option>Credit/Debit Card</option>
                            <option>Demand Draft</option>
                            <option>Cheque</option>
                            <option>Cash</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className='row'>
<div className="col-md-6">
  <div className="mb-3">
    <label className="form-label">Supplier *</label>
    <select
      className="form-select"
      name="supplierId"
      value={formData.supplierId}
      onChange={handleSupplierChange}
      required
    >
      <option value="">Select Supplier</option>
      {suppliers
        .filter(supp => supp.role === "supplier")
        .map((supp) => (
     <option key={supp.id} value={supp.id}>
  {supp.gstin?.trim()
    ? supp.display_name || supp.name
    : supp.name || supp.display_name}
</option>

        ))}
    </select>
  </div>
</div>
        
            <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Invoice Number *</label>
                          <select
                            className="form-select"
                            name="invoiceNumber"
                            value={formData.invoiceNumber}
                            onChange={handleInvoiceChange}
                            required
                          >
                            <option value="">Select Invoice Number</option>
                            {invoices.length > 0 ? (
                              invoices.map((invoice) => (
                                <option key={invoice.id} value={invoice.number}>
                                  {invoice.number}
                                </option>
                              ))
                            ) : (
                              <option value="" disabled>No invoices found</option>
                            )}
                          </select>
                          {invoices.length === 0 && (
                            <small className="text-danger">
                              No invoices available. Please check if invoices are created.
                            </small>
                          )}
                        </div>
                      </div>
                      </div>
                    <div className="row mb-4">
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Amount *</label>
                          <div className="input-group custom-amount-receipts-table">
                            <select
                              className="form-select currency-select-receipts-table"
                              name="currency"
                              value={formData.currency}
                              onChange={handleInputChange}
                            >
                              <option>INR</option>
                              <option>USD</option>
                              <option>EUR</option>
                              <option>GBP</option>
                            </select>
                            <input
                              type="number"
                              className="form-control amount-input-receipts-table"
                              name="amount"
                              value={formData.amount}
                              onChange={handleInputChange}
                              placeholder={invoiceBalance > 0 ? "Auto-filled from balance" : "Enter amount"}
                              min="0"
                              step="0.01"
                              required
                            />
                          </div>
                          {invoiceBalance > 0 && formData.amount && (
                            <small className="text-success">
                              <i className="bi bi-check-circle me-1"></i>
                              Auto-filled from invoice balance
                            </small>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Note</label>
                          <textarea
                            className="form-control"
                            rows="3"
                            name="note"
                            value={formData.note}
                            onChange={handleInputChange}
                            placeholder="Additional notes..."
                          ></textarea>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Bank Name</label>
                          <input
                            type="text"
                            className="form-control"
                            name="bankName"
                            value={formData.bankName}
                            onChange={handleInputChange}
                            placeholder="Bank Name"
                          />
                        </div>
                        <div className="mb-3">
                          <label className="form-label">Transaction Proof Document</label>
                          <input 
                            type="file" 
                            className="form-control" 
                            onChange={(e) => handleFileChange(e)}
                            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                          />
                          <small className="text-muted">
                            {formData.transactionProofFile ? formData.transactionProofFile.name : 'No file chosen'}
                          </small>
                          
                          {formData.transactionProofFile && (
                            <div className="mt-2">
                              <div className="d-flex align-items-center">
                                <span className="badge bg-success me-2">
                                  <i className="bi bi-file-earmark-check"></i>
                                </span>
                                <span className="small">
                                  {formData.transactionProofFile.name} 
                                  ({Math.round(formData.transactionProofFile.size / 1024)} KB)
                                </span>
                                <button 
                                  type="button" 
                                  className="btn btn-sm btn-outline-danger ms-2"
                                  onClick={() => handleRemoveFile()}
                                >
                                  <i className="bi bi-x"></i>
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="mb-3">
                          <label className="form-label">Transaction Date</label>
                          <input
                            type="date"
                            className="form-control"
                            name="transactionDate"
                            value={formData.transactionDate}
                            onChange={handleInputChange}
                          />
                        </div>
                        <div className="mb-3">
                          <label className="form-label">Reconciliation Option</label>
                          <select
                            className="form-select"
                            name="reconciliationOption"
                            value={formData.reconciliationOption}
                            onChange={handleInputChange}
                          >
                            <option>Do Not Reconcile</option>
                            <option>Customer Reconcile</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={handleCloseModal}
                      disabled={isLoading}
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={handleCreateReceipt}
                      disabled={isLoading || !formData.amount || parseFloat(formData.amount) <= 0}
                    >
                      {isLoading ? 'Creating...' : 'Create Voucher'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VochurTable;